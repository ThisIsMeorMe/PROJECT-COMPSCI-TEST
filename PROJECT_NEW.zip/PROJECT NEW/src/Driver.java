public class Driver {
    
    public Driver() {
        new FoodEach("apple", 3, 0, true);
        new FoodEach("apple_pie", 5, 10, false);
        new FoodEach("avocado", 10, 25, false);
        new FoodEach("boar_head", 15, 50, false);
        new FoodEach("bread", 25, 70, false);
        new FoodEach("cheese", 40, 120, false);
        new FoodEach("cheesecake", 60, 200, false);
        new FoodEach("chicken", 100, 350, false);
        new FoodEach("cookie", 150, 500, false);
        new FoodEach("dragon_fruit", 200, 750, false);
        new FoodEach("fish", 300, 1000, false);
        new FoodEach("fried_eggs", 500, 1500, false);
        new FoodEach("honey", 750, 2000, false);
        new FoodEach("pineapple", 1000, 3000, false);
        new FoodEach("pretzel", 1500, 5000, false);
        new FoodEach("pumpkin_pie", 2500, 10000, false);
        new FoodEach("shrimp", 5000, 20000, false);
        new FoodEach("sushi", 7500, 30000, false);
        new FoodEach("t-bone", 10000, 50000, false);
        new FoodEach("watermelon", 50000, 100000, false);
    }
}
