# COMPSCI-PROJECT

## Windows Double-Click Run

If you want to run the game on Windows by double-clicking a start file, follow these steps:

- Build an executable JAR (a `Game.jar` is generated when you run the commands below). If you need to rebuild locally, run:

```bash
mkdir -p bin
javac -d bin src/*.java
jar cfe Game.jar Main -C bin . -C . assets README.md
```

- Copy `Game.jar` and the `run-windows.bat` file to the same folder on your Windows machine.

- Double-click `run-windows.bat`. The batch script will:
	- Change to the script directory so bundled `assets/` are found inside the jar.
	- Check that `java` is on the PATH and show a message if missing.
	- Launch the jar using `java -jar Game.jar`.

### Notes

- If you don't have Java installed on Windows, install OpenJDK 17 or newer (Adoptium, Oracle, or other vendors).
- You can also double-click `Game.jar` directly if your Windows system associates `.jar` files with Java. The batch file is safer because it prints helpful messages if Java is missing.

Enjoy!